### Hexlet tests and linter status:
[![Actions Status](https://github.com/gleb-fake-git/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/gleb-fake-git/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/93eb3abfcdbf8ae42620/maintainability)](https://codeclimate.com/github/gleb-fake-git/python-project-49/maintainability)
[![Maintainability](https://api.codeclimate.com/v1/badges/93eb3abfcdbf8ae42620/maintainability)](https://codeclimate.com/github/gleb-fake-git/python-project-49/maintainability)

brain-even:
[![asciicast](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1.png)](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1)

brain-calc:
[![asciicast](https://asciinema.org/a/pjIJAz4oCWNRySSPTrisspyib.png)](https://asciinema.org/a/pjIJAz4oCWNRySSPTrisspyib)

brain-gcd:
[![asciicast](https://asciinema.org/a/aqNCXXMD5Zz9WlL76TS1cQJ99.png)](https://asciinema.org/a/aqNCXXMD5Zz9WlL76TS1cQJ99)

brain-progression:
[![asciicast](https://asciinema.org/a/iUjICMryhVGXAyEWyUm6oCl1e.png)](https://asciinema.org/a/iUjICMryhVGXAyEWyUm6oCl1e)

brain-prime:
[![asciicast](https://asciinema.org/a/hTYBtxbEkov4diirw8TF9Bncu.png)](https://asciinema.org/a/hTYBtxbEkov4diirw8TF9Bncu)
