### Hexlet tests and linter status:
[![Actions Status](https://github.com/gleb-fake-git/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/gleb-fake-git/python-project-49/actions)


brain-even:
[![asciicast](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1.png)](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1)

brain-calc:
[![asciicast](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1.png)](https://asciinema.org/a/XbdDtY6qsL4tfiDb5X4ZahZV1)